from .cli_app import main

main()
