from .isholidays import main

main()
