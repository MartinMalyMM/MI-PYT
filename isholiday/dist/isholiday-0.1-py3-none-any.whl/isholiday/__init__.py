from .isholidays import getholidays, isholiday # ta tecka dela relativni import

__all__ = ['getholidays', 'isholiday']
